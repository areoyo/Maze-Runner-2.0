/*
    ALEJANDRA DELGADO REOYO
*/

var cubeVerticesBuffer;
var cubeVerticesTextureCoordBuffer;
var cubeVerticesIndexBuffer;
var cubeVerticesNormalBuffer;

var gl;
var cubeTexture;

var MAZESZ = 15;
var my_maze = new Maze(MAZESZ);
var goal = new Pos(0, 0);
var centre = Math.floor(MAZESZ/2);
var radius = 6;
var finish;
var posCube = {
  x: [],
  y: [],
  length: 0.0,
}

var n = 10;
var enemy = [];
var lives = 3.0;
var nbomb = 25;
var ts = 0;
var level = 1;
var posObstacle = {
  x: [],
  y: [],
  length: 0.0,
  drawX : [],
  drawY : [],
}
var rotation = 0.0;
var lastUpdateTime = 0;

var pos = [centre, centre, 0.5];
var perspective = [centre+1, centre, 0.0];
var angulo = 0.0;
var v = [Math.cos(angulo), Math.sin(angulo), 0.0];

var texture_src = ["resources/06.jpg", "resources/05.jpg", "resources/block.jpg",  "resources/03.png", "resources/04.jpg" ];
var fogStart = -0.1;
var fogEnd = 0.5;
var directionalLightColor = [0.0, 0.0, 0.0];
var ambientLightColor = [0.3, 0.25, 0.25];
var fogColor = [0.5, 0.5, 0.3];
var directionalLight = false;
var changeUp = false;
var pointUp = false;

var score = 0;
var timeout = 90;
var timeRefence;

var VSHADER_SOURCE =

  'attribute highp vec3 a_VertexPosition;\n' +
  'attribute highp vec2 a_TextureCoord;\n' +
  'attribute highp vec3 a_VertexNormal;\n' +

  'uniform highp mat4 u_NormalMatrix;\n' +
  'uniform highp mat4 u_MvpMatrix;\n' +
  'uniform highp mat4 u_ModelMatrix;\n' +

  'varying highp vec2 v_TextureCoord;\n' +
	'varying highp vec4 v_vertexPosition;\n' +
	'varying highp vec4 v_TransformedNormal;\n' +

  'void main() {\n' +
  '  gl_Position = u_MvpMatrix * vec4(a_VertexPosition, 1.0);\n' +
  '  v_TextureCoord = a_TextureCoord;\n' +

  '  v_vertexPosition = u_ModelMatrix * vec4(a_VertexPosition, 1.0);\n' +
  '  v_TransformedNormal = u_NormalMatrix * vec4(a_VertexNormal, 1.0);\n' +

  '}\n';

var FSHADER_SOURCE =

  '#ifdef GL_ES\n' +
  'precision mediump float;\n' +
  '#endif\n' +

  'varying highp vec2 v_TextureCoord;\n' +
  'varying highp vec4 v_vertexPosition;\n' +
  'varying highp vec4 v_TransformedNormal;\n' +

  'uniform sampler2D u_image0;\n' +
  'uniform sampler2D u_image1;\n' +
  'uniform highp vec3 u_PointLightPosition;\n' +
  'uniform highp vec3 u_directionalLightColor;\n' +
  'uniform highp vec3 u_ambientLightColor;\n' +
  'uniform highp vec3 u_fogColor;\n' +
  'uniform highp vec3 u_eyePosition;\n' +
  'uniform highp float u_fogStart;\n' +
	'uniform highp float u_fogEnd;\n' +

	'const highp float FogDensity = 1.0;\n' +

  'void main() {\n' +
  '  highp vec3 ambientLight = u_ambientLightColor;\n' +
  '  highp vec3 directionalLightColor = u_directionalLightColor;\n' +
	'  highp vec3 PointLightingSpecularColor = vec3(1.0, 1.0, 1.0);\n' +
  '  highp vec3 pointLightPosition = u_PointLightPosition;\n' +

	'  highp float materialShiness = 1.0;\n' +

  '	 highp float fogFactor = ((v_vertexPosition.z/v_vertexPosition.w)-u_fogStart) / (u_fogEnd - u_fogStart);\n' +
	'	 fogFactor = clamp(fogFactor, 0.0, 1.0 );\n' +

	'  highp vec3 normal = normalize(v_TransformedNormal.xyz);\n'+
  '  highp vec3 eyeDirection = normalize(u_eyePosition-v_vertexPosition.xyz);\n'+

	'  highp vec3 lightDirection = normalize((pointLightPosition - v_vertexPosition.xyz));\n' +
	'  highp vec3 reflectionDirection = reflect(-lightDirection, normal);\n'+

	'  highp float specularLightWeighting = pow(max(dot(reflectionDirection, eyeDirection), 0.0), materialShiness);\n'+
	'  highp float directionalW = max(dot(v_TransformedNormal.xyz, lightDirection), 0.0);\n' +

  '  highp vec3 v_Lighting = ambientLight + (PointLightingSpecularColor * specularLightWeighting) + (directionalLightColor * directionalW);\n' + //

  '  highp vec4 color0 = texture2D(u_image0, vec2(v_TextureCoord.s, v_TextureCoord.t));\n' +
  '  highp vec4 color1 = texture2D(u_image1, vec2(v_TextureCoord.s, v_TextureCoord.t));\n' +

  '  gl_FragColor = vec4(u_fogColor*(1.0-fogFactor), 1.0) + fogFactor*vec4((color0*color1).rgb * v_Lighting, (color0*color1).a);\n' +

  '}\n';

function createMaze () {

  for(var i = 0; i < MAZESZ; i++){
    for(var j = 0; j < MAZESZ; j++){
      if(my_maze.rooms[i][j] === false){
        posCube.x.push(i);
        posCube.y.push(j);
        posCube.length++;
      } else {
        if ((i !== pos[0] || j !== pos[1]) && (i !== goal.x || j !== goal.y)){
          posObstacle.x.push(i);
          posObstacle.y.push(j);
          posObstacle.length++;
        }
      }
    }
  }
}

function initBuffers (){

    cubeVerticesBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVerticesBuffer);

    var vertices = new Float32Array([
      -1.0, -1.0,  1.0,  1.0, -1.0,  1.0,  1.0,  1.0,  1.0, -1.0,  1.0,  1.0,   // Front face
      -1.0, -1.0, -1.0, -1.0,  1.0, -1.0,  1.0,  1.0, -1.0,  1.0, -1.0, -1.0,   // Back face
      -1.0,  1.0, -1.0, -1.0,  1.0,  1.0,  1.0,  1.0,  1.0,  1.0,  1.0, -1.0,   // Top face
      -1.0, -1.0, -1.0,  1.0, -1.0, -1.0,  1.0, -1.0,  1.0, -1.0, -1.0,  1.0,   // Bottom face
       1.0, -1.0, -1.0,  1.0,  1.0, -1.0,  1.0,  1.0,  1.0,  1.0, -1.0,  1.0,   // Right face
      -1.0, -1.0, -1.0, -1.0, -1.0,  1.0, -1.0,  1.0,  1.0, -1.0,  1.0, -1.0    // Left face
    ]);
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

    cubeVerticesNormalBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVerticesNormalBuffer);

    var vertexNormals = new Float32Array([
       0.0,  0.0,  1.0,  0.0,  0.0,  1.0,  0.0,  0.0,  1.0,  0.0,  0.0,  1.0,   // Front face
       0.0,  0.0, -1.0,  0.0,  0.0, -1.0,  0.0,  0.0, -1.0,  0.0,  0.0, -1.0,   // Back face
       0.0,  1.0,  0.0,  0.0,  1.0,  0.0,  0.0,  1.0,  0.0,  0.0,  1.0,  0.0,   // Top face
       0.0, -1.0,  0.0,  0.0, -1.0,  0.0,  0.0, -1.0,  0.0,  0.0, -1.0,  0.0,   // Bottom face
       1.0,  0.0,  0.0,  1.0,  0.0,  0.0,  1.0,  0.0,  0.0,  1.0,  0.0,  0.0,   // Right face
      -1.0,  0.0,  0.0, -1.0,  0.0,  0.0, -1.0,  0.0,  0.0, -1.0,  0.0,  0.0   // Left face
    ]);
    gl.bufferData(gl.ARRAY_BUFFER, vertexNormals, gl.STATIC_DRAW);

    cubeVerticesTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVerticesTextureCoordBuffer);

    var textureCoordinates = new Float32Array([
      0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0,  // Front
      0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0,  // Back
      0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0,  // Top
      0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0,  // Bottom
      0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0,  // Right
      0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0   // Left
    ]);
    gl.bufferData(gl.ARRAY_BUFFER, textureCoordinates, gl.STATIC_DRAW);

    cubeVerticesIndexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, cubeVerticesIndexBuffer);

    var cubeVertexIndices =  new Uint16Array([
      0,  1,  2,      0,  2,  3,    // front
      4,  5,  6,      4,  6,  7,    // back
      8,  9,  10,     8,  10, 11,   // top
      12, 13, 14,     12, 14, 15,   // bottom
      16, 17, 18,     16, 18, 19,   // right
      20, 21, 22,     20, 22, 23    // left
    ]);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, cubeVertexIndices, gl.STATIC_DRAW);
}

function initTextures (src) {
  cubeTexture = gl.createTexture();
  var cubeImage = new Image();
  cubeImage.onload = function() { handleTextureLoaded(cubeImage, cubeTexture); }
  cubeImage.src = src;
}

function handleTextureLoaded(image, texture) {
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_NEAREST);
  gl.generateMipmap(gl.TEXTURE_2D);
  gl.bindTexture(gl.TEXTURE_2D, null);
}

function Pyramid (texture, texture2) {

  this.texture = texture;
  this.texture2 = texture2;

  this.verticesBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesBuffer);

  this.vertices = new Float32Array([
    -1.0, -1.0, -1.0,    1.0, -1.0, -1.0,    1.0, 1.0, -1.0,    0.0,  0.0, 0.0,
    -1.0, -1.0, -1.0,    1.0,  1.0, -1.0,   -1.0, 1.0, -1.0,    0.0,  0.0, 0.0,
    -1.0, -1.0, -1.0,   -1.0,  1.0, -1.0,    0.0,  0.0,  1.0,   0.0,  0.0, 0.0,
    -1.0, -1.0, -1.0,    1.0, -1.0, -1.0,    0.0,  0.0,  1.0,   0.0,  0.0, 0.0,
     1.0, -1.0, -1.0,    1.0,  1.0, -1.0,    0.0,  0.0,  1.0,   0.0,  0.0, 0.0,
     1.0,  1.0, -1.0,   -1.0,  1.0, -1.0,    0.0,  0.0,  1.0,   0.0,  0.0, 0.0,
  ]);
  gl.bufferData(gl.ARRAY_BUFFER, this.vertices, gl.STATIC_DRAW);

  this.verticesTextureCoordBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesTextureCoordBuffer);

  this.textureCoordinates = new Float32Array([
    0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0,  // Front
    0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0,  // Back
    0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0,  // Top
    0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0,  // Bottom
    0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0,  // Right
    0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0   // Left
  ]);
  gl.bufferData(gl.ARRAY_BUFFER, this.textureCoordinates, gl.STATIC_DRAW);

  this.verticesIndexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.verticesIndexBuffer);

  this.vertexIndices = new Uint16Array([
    0,  1,  2,
    4,  5,  6,
    8,  9, 10,
    12, 13, 14,
    16, 17, 18,
    20, 21, 22,
  ]);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.vertexIndices, gl.STATIC_DRAW);

  this.initTexture = function() {
    texture00 = gl.createTexture();
    var image = new Image();
    image.onload = function() { handleTextureLoaded(image, texture00); }
    image.src = this.texture;

    texture01 = gl.createTexture();
    var image01 = new Image();
    image01.onload = function() { handleTextureLoaded(image01, texture01); }
    image01.src = this.texture2;
  }

  this.pos = function(){
    var option = Math.floor(Math.random() * posObstacle.x.length);
    var posX = posObstacle.x[option];
    var posY = posObstacle.y[option];
    posObstacle.x.splice(option,1);
    posObstacle.y.splice(option,1);
    posObstacle.drawX.push(posX);
    posObstacle.drawY.push(posY);
    return posObstacle;
  }

  this.draw = function(x, y, mMatrix, pMatrix, vMatrix, mvpMatrix, u_ModelMatrix, u_MvpMatrix){
    this.mMatrix = mMatrix;
    this.mvpMatrix = mvpMatrix;

    this.mMatrix.setTranslate(x, y, 0.5).rotate(rotation, 0, 0, 1).scale(0.3,0.3,0.3);
    this.mvpMatrix.set(pMatrix).multiply(vMatrix).multiply(mMatrix);

    gl.uniformMatrix4fv(u_ModelMatrix, false, mMatrix.elements);
    gl.uniformMatrix4fv(u_MvpMatrix, false, mvpMatrix.elements);

    vertexPositionAttribute = gl.getAttribLocation(gl.program, "a_VertexPosition");
    gl.enableVertexAttribArray(vertexPositionAttribute);

    textureCoordAttribute = gl.getAttribLocation(gl.program, "a_TextureCoord");
    gl.enableVertexAttribArray(textureCoordAttribute);

    gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesBuffer);
    gl.vertexAttribPointer(vertexPositionAttribute, 3, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesTextureCoordBuffer);
    gl.vertexAttribPointer(textureCoordAttribute, 2, gl.FLOAT, false, 0, 0);

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture00);
    gl.uniform1i(gl.getUniformLocation(gl.program, "u_image0"), 0);

    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, texture01);
    gl.uniform1i(gl.getUniformLocation(gl.program, "u_image1"), 1);

    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.verticesIndexBuffer);

    gl.drawElements(gl.TRIANGLES, 18, gl.UNSIGNED_SHORT, 0);


    var currentTime = (new Date).getTime();
    if (lastUpdateTime) {
      var delta = currentTime - lastUpdateTime;
      rotation += 2 * ((30 * delta) / 1000.0);
    }
    lastUpdateTime = currentTime;
  }

  this.collision = function(x, y){
    length = posObstacle.drawX.length;
    for (var i = 0; i < length; i++){
      var posX = Math.round(x);
      var posY = Math.round(y);
      if (posX === posObstacle.drawX[i] && posY === posObstacle.drawY[i]){
        console.log("COLISION");
        return true;
        break;
      }
    }
  }
}

function Flat(texture, elevation){

  this.texture = texture;
  this.up = elevation;

  this.verticesBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesBuffer);

  this.vertices = new Float32Array([
    -1.0, -1.0, 0.0,  -1.0, 1.0, 0.0,  1.0, -1.0, 0.0,   1.0, 1.0, 0.0,
  ]);
  gl.bufferData(gl.ARRAY_BUFFER, this.vertices, gl.STATIC_DRAW);

  this.verticesTextureCoordBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesTextureCoordBuffer);

  this.textureCoordinates = new Float32Array([
    0.0,  0.0,     1.0,  0.0,     1.0,  1.0,     0.0,  1.0,
  ]);
  gl.bufferData(gl.ARRAY_BUFFER, this.textureCoordinates, gl.STATIC_DRAW);

  this.verticesIndexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.verticesIndexBuffer);

  this.vertexIndices = new Uint16Array([
    0,  1,  2,      1,  2,  3,
  ]);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.vertexIndices, gl.STATIC_DRAW);

  this.initTexture = function() {
    texture0 = gl.createTexture();
    var image = new Image();
    image.onload = function() { handleTextureLoaded(image, texture0); }
    image.src = this.texture;
  }

  this.drawFlat = function(mMatrix, pMatrix, vMatrix, mvpMatrix, u_ModelMatrix, u_MvpMatrix){
    this.mMatrix = mMatrix;
    this.mvpMatrix = mvpMatrix;
    size = MAZESZ + 1;
    for(var i = 0; i < size; i++){
      for(var j = 0; j < size; j++){
        this.mMatrix.setTranslate(i, j, this.up);
        this.mvpMatrix.set(pMatrix).multiply(vMatrix).multiply(mMatrix);

        gl.uniformMatrix4fv(u_ModelMatrix, false, mMatrix.elements);
        gl.uniformMatrix4fv(u_MvpMatrix, false, mvpMatrix.elements);

        vertexPositionAttribute = gl.getAttribLocation(gl.program, "a_VertexPosition");
        gl.enableVertexAttribArray(vertexPositionAttribute);

        textureCoordAttribute = gl.getAttribLocation(gl.program, "a_TextureCoord");
        gl.enableVertexAttribArray(textureCoordAttribute);

        gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesBuffer);
        gl.vertexAttribPointer(vertexPositionAttribute, 3, gl.FLOAT, false, 0, 0);

        gl.bindBuffer(gl.ARRAY_BUFFER, this.verticesTextureCoordBuffer);
        gl.vertexAttribPointer(textureCoordAttribute, 2, gl.FLOAT, false, 0, 0);

        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, texture0);
        gl.uniform1i(gl.getUniformLocation(gl.program, "u_image0"), 0);

        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.verticesIndexBuffer);

        gl.drawElements(gl.TRIANGLES, 6, gl.UNSIGNED_SHORT, 0);
      }
    }
  }
}

function alive() {

  switch(lives) {
  	case 3.0:
      ctx_2d.drawImage(img_live, 750, 18);
      ctx_2d.drawImage(img_live, 720, 18);
      ctx_2d.drawImage(img_live, 690, 18);
      break;
    case 2.0:
      ctx_2d.drawImage(img_live, 750, 18);
      ctx_2d.drawImage(img_live, 720, 18);
      break;
    case 1.0:
      ctx_2d.drawImage(img_live, 750, 18);
      break;
    default:
      stopGame();
  }
}

function setclock(){
  var t = new Date().getTime();
  t = Math.abs(Math.round(t/1000) - timeRefence);
  return t;
}

function keydown(ev) {

  var posNext = [pos[0], pos[1]];
  var posPrev = [(pos[0]-v[0]/4) , (pos[1]-v[1]/4)];
  var posShoot = [pos[0], pos[1]];

  switch(ev.keyCode){
    case 38: // delante
      posNext[0] += v[0]/4;
      posNext[1] += v[1]/4;
      break;
    case 40:// atras
      posNext[0] -= v[0]/4;
      posNext[1] -= v[1]/4;
      break;
    case 39 :// girar derecha
      angulo -= Math.PI/6;
      break;
    case 37:// girar izq
      angulo += Math.PI/6;
      break;
    case 13: // LUZ - enter
      if (directionalLight === true){
        directionalLightColor = [0.0, 0.0, 0.0];
        directionalLight = false;
        img = img_torchOff;
      } else {
        directionalLightColor = [0.65, 0.42, 0.34];
        directionalLight = true;
        img = img_torchOn;
      };
      break;
    case 17: // CNTRL --> VISTA DESDE ARRIBA
      if (pointUp === true){
        changeUp = false;
        pointUp = false;
        directionalLightColor = [0.0, 0.0, 0.0];
      } else {
        changeUp = true;
        pointUp = true;
        directionalLightColor = [1.0, 0.0, 0.0];
      };
      break;
      case 32: // SPACE --> DISPARO
        console.log("DISPARO");
        posShoot[0] += 3 * v[0]/4;
        posShoot[1] += 3 * v[1]/4;
        if (nbomb > 0){
          //ctx_2d.drawImage(img_bomb, 400, 200);
          ts = setclock();
          nbomb--;
        }
        break;
    default:
      console.log("Key not handled");
  }

  posNext_2D = [Math.round(posNext[0]), Math.round(posNext[1])];

  if (my_maze.rooms[posNext_2D[0]][posNext_2D[1]] !== false) {
    pos[0] = posNext[0];
    pos[1] = posNext[1];
  }

  for (var i = 0; i < enemy.length; i++){
    if (enemy[i].collision(pos[0], pos[1]) === true){
      posObstacle.drawX.splice(i,1);
      posObstacle.drawY.splice(i,1);
      enemy.splice(i,1);
      enemy[i].pos();
      lives--;
      pos[0] = posPrev[0];
      pos[1] = posPrev[1];
      break;
    };
    if (enemy[i].collision(posShoot[0], posShoot[1]) === true){
      posObstacle.drawX.splice(i,1);
      posObstacle.drawY.splice(i,1);
      enemy.splice(i,1);
      score += 5;
      console.log('ELIMINADO')
      break;
    };
  }

  v = [Math.cos(angulo), Math.sin(angulo), 0];
  perspective[0] = pos[0] + v[0];
  perspective[1] = pos[1] + v[1];
  my_maze.pos.x = Math.round(pos[0]);
  my_maze.pos.y = Math.round(pos[1]);

  final();
  nextStage();
}

function drawMaze() {

  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  ctx_2d.clearRect(0, 0, canvas2d.width, canvas2d.height);

  if (setclock() === 0){
    lives = 0;
  } else if (setclock() > 85){
    ctx_2d.font = '30pt VTFMisterPixelRegular';
    ctx_2d.fillText('Press ENTER and TURN ON THE TORCH' , 50, canvas2d.height-120);
    ctx_2d.fillText('Press SPACE and SHOOT' , 50, canvas2d.height-80);
  } else if (setclock() === 70){
    fogStart = -0.1;
    fogEnd = 0.75;
    fogColor = [0.3, 0.1, 0.3];
  } else if (setclock() === 50){
    fogStart = -0.05;
    fogEnd = 0.75;
    fogColor = [0.3, 0.3, 0.3];
  } else if (setclock() === 30){
    fogStart = 0.0;
    fogEnd = 1.05;
    fogColor = [0.6, 0.2, 0.1];
  } else if (setclock() === 15){
    ambientLightColor = [1.0, 0.1, 0.1];
    fogColor = [1.0, 0.1, 0.1];
  } else if ((setclock() < ts) && (setclock() >= (ts-2))){
    ctx_2d.drawImage(img_bomb, canvas2d.width/2 - 85, canvas2d.height/2 - 87);
    ts = 0;
  }

  alive();

  var u_PointLightPosition = gl.getUniformLocation(gl.program, 'u_PointLightPosition');
  if (!u_PointLightPosition) {
    console.log('Failed to get the storage location of u_PointLightPosition');
    return;
  }

  var u_directionalLightColor = gl.getUniformLocation(gl.program, 'u_directionalLightColor');
  if (!u_directionalLightColor) {
    console.log('Failed to get the storage location of u_directionalLightColor');
    return;
  }
  gl.uniform3fv(u_directionalLightColor, directionalLightColor);

  var u_ambientLightColor = gl.getUniformLocation(gl.program, 'u_ambientLightColor');
  if (!u_ambientLightColor) {
    console.log('Failed to get the storage location of u_ambientLighColor');
    return;
  }
  gl.uniform3fv(u_ambientLightColor, ambientLightColor);

  var u_fogColor = gl.getUniformLocation(gl.program, 'u_fogColor');
  if (!u_fogColor) {
    console.log('Failed to get the storage location of u_fogColor');
    return;
  }
  gl.uniform3fv(u_fogColor, fogColor);

  var u_eyePosition = gl.getUniformLocation(gl.program, 'u_eyePosition');
  if (!u_eyePosition) {
    console.log('Failed to get the storage location of u_eyePosition');
    return;
  }

  var u_MvpMatrix = gl.getUniformLocation(gl.program, 'u_MvpMatrix');
  if (!u_MvpMatrix) {
    console.log('Failed to get the storage location of u_MvpMatrix');
    return;
  }

  var u_ModelMatrix = gl.getUniformLocation(gl.program, 'u_ModelMatrix');
  if (!u_ModelMatrix) {
    console.log('Failed to get the storage location of u_ModelMatrix');
    return;
  }

  var u_fogStart = gl.getUniformLocation(gl.program, 'u_fogStart');
  if (!u_fogStart) {
    console.log('Failed to get the storage location of u_fogStart');
    return;
  }
  gl.uniform1f(u_fogStart, fogStart);

  var u_fogEnd = gl.getUniformLocation(gl.program, 'u_fogEnd');
  if (!u_fogEnd) {
    console.log('Failed to get the storage location of u_fogEnd');
    return;
  }
  gl.uniform1f(u_fogEnd, fogEnd);

  var mMatrix   = new Matrix4();
  var vMatrix   = new Matrix4();
  var pMatrix   = new Matrix4();
  var mvpMatrix = new Matrix4();

  var bomb = 'x'+nbomb;
  var scores = 'score '+score;
  var stage = 'stage '+level;

  pMatrix.setPerspective(90, 1, 0.00005, 50);

  ctx_2d.font = '15pt VTFMisterPixelRegular';
  ctx_2d.fillStyle = 'WHITE';
  ctx_2d.fillText(scores, 650, 55);
  ctx_2d.fillText(stage, 650, 75);
  if (nbomb === 0){
    ctx_2d.drawImage(img_weaponOff, 755, 135);
  } else {
    ctx_2d.drawImage(img_weapon, 755, 135);
    ctx_2d.fillText(bomb, 750, 158);
  }
  ctx_2d.drawImage(img, 755, 90);

  ctx_2d.font = '30pt VTFMisterPixelRegular';
  ctx_2d.fillText(setclock(), canvas2d.width/2 - 50, 55);

  if (changeUp === false){
    ctx_2d.font = '7pt Times New Romans';
    ctx_2d.fillText('|ctrl| to extend', 65, 20);
    my_maze.draw(ctx_2d, 10, 15, 5, radius);

    eyePosition = [pos[0] + 0.5, pos[1] + 0.5, 0.75];
    lookEye = [perspective[0] + 0.5, perspective[1] + 0.5, 0.75];
    pointlight = [pos[0] + 0.5, pos[1] + 0.5, 1];

    sky.up = 1.55;
    axis = [0, 0, 1];
  } else {
    eyePosition = [pos[0] + 0.5, pos[1] + 0.5, 7];
    lookEye = [pos[0] + 0.5, pos[1] + 0.5, 0.0];
    pointlight = [pos[0] + 0.5, pos[1] + 0.5, 0.25];

    sky.up = floor.up;
    axis = [0, -1, 0]
  };

  gl.uniform3fv(u_PointLightPosition, pointlight);
  gl.uniform3fv(u_eyePosition, eyePosition);
  vMatrix.setLookAt(eyePosition[0], eyePosition[1], eyePosition[2], lookEye[0], lookEye[1], lookEye[2], axis[0], axis[1], axis[2]);

  floor.drawFlat(mMatrix, pMatrix, vMatrix, mvpMatrix, u_ModelMatrix, u_MvpMatrix);
  sky.drawFlat(mMatrix, pMatrix, vMatrix, mvpMatrix, u_ModelMatrix, u_MvpMatrix);

  for (var i = 0; i < enemy.length; i++){
    var xx = posObstacle.drawX[i]+0.5;
    var yy = posObstacle.drawY[i]+0.5

    enemy[i].draw(xx, yy, mMatrix, pMatrix, vMatrix, mvpMatrix, u_ModelMatrix, u_MvpMatrix);
  }

  for (var i = 0; i < posCube.length; i++){
    var x = posCube.x[i] + 0.5;
    var y = posCube.y[i] + 0.5;

    mMatrix.setTranslate(x, y, 0.75).scale(0.5, 0.5, 0.75);
    mvpMatrix.set(pMatrix).multiply(vMatrix).multiply(mMatrix);

    gl.uniformMatrix4fv(u_ModelMatrix, false, mMatrix.elements);
    gl.uniformMatrix4fv(u_MvpMatrix, false, mvpMatrix.elements);

    vertexPositionAttribute = gl.getAttribLocation(gl.program, "a_VertexPosition");
    gl.enableVertexAttribArray(vertexPositionAttribute);

    textureCoordAttribute = gl.getAttribLocation(gl.program, "a_TextureCoord");
    gl.enableVertexAttribArray(textureCoordAttribute);

    vertexNormalAttribute = gl.getAttribLocation(gl.program, "a_VertexNormal");
    gl.enableVertexAttribArray(vertexNormalAttribute);

    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVerticesBuffer);
    gl.vertexAttribPointer(vertexPositionAttribute, 3, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVerticesTextureCoordBuffer);
    gl.vertexAttribPointer(textureCoordAttribute, 2, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, cubeVerticesNormalBuffer);
    gl.vertexAttribPointer(vertexNormalAttribute, 3, gl.FLOAT, false, 0, 0);

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, cubeTexture);
    gl.uniform1i(gl.getUniformLocation(gl.program, "u_Sampler"), 0);

    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, cubeVerticesIndexBuffer);

    var normalMatrix = new Matrix4();
    normalMatrix.set(mMatrix);
    normalMatrix.invert();
    normalMatrix.transpose();
    var nUniform = gl.getUniformLocation(gl.program, "u_NormalMatrix");
    gl.uniformMatrix4fv(nUniform, false, normalMatrix.elements);

    gl.drawElements(gl.TRIANGLES, 36, gl.UNSIGNED_SHORT, 0);
  }

  document.onkeydown = function(ev){keydown(ev)};
  requestAnimationFrame(drawMaze);
}

function final(){

  var x = my_maze.pos.x;
  var y = my_maze.pos.y;

  if ((x <= goal.x) && ( y <= goal.y)){
    finish = true;
  }
}

function nextStage (){

  if (finish === true){

    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    ctx_2d.clearRect(0, 0, canvas2d.width, canvas2d.height);

    finish = false;
    score = setclock();

    MAZESZ += 5;
    my_maze = new Maze(MAZESZ);
    goal = new Pos(0,0);
    centre = Math.floor(MAZESZ/2);
    radius = 3;
    posCube = {
      x: [],
      y: [],
      length: 0.0,
    }

    pos = [centre, centre, 0.5];
    perspective = [centre+1, centre, 0.0];
    angulo = 0.0;
    v = [Math.cos(angulo), Math.sin(angulo), 0.0];
    n += 2;
    nbomb += 15;

    timeout -= 5;;

    level ++;

    startGame();
  }
}

function stopGame(){

  ctx_2d.drawImage(img_gameOver, 310, 150);
  requestAnimationFrame(finish);

}

function srcImages (){

  img_live = new Image();
  img_live.src = "resources/lives.png";

  img_torchOn = new Image();
  img_torchOn.src = "resources/torch.png";

  img_torchOff = new Image();
  img_torchOff.src = "resources/torchoff.png";

  img_weapon = new Image();
  img_weapon.src = "resources/weapon.png";

  img_weaponOff = new Image();
  img_weaponOff.src = "resources/weaponoff.png";

  img_gameOver = new Image();
  img_gameOver.src = "resources/gameover.png";

  img_bomb = new Image();
  img_bomb.src = "resources/bomb4.png"

  img = img_torchOff;
}

function startGame() {
  var canvas = document.getElementById('webgl');
  canvas2d = document.getElementById('2d');
	ctx_2d = canvas2d.getContext("2d");

  gl = getWebGLContext(canvas);
  if (!gl) {
    console.log('Failed to get the rendering context for WebGL');
    return;
  }

  if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
    console.log('Failed to intialize shaders.');
    return;
  }

  my_maze.randPrim(goal);
  createMaze();

  if (gl) {
    gl.clearColor(0.7, 0.7, 0.5, 1.0);  // Clear to black, fully opaque
    gl.clearDepth(1.0);                 // Clear everything
    gl.enable(gl.DEPTH_TEST);           // Enable depth testing
    gl.depthFunc(gl.LEQUAL);            // Near things obscure far things

    timeRefence = new Date().getTime();
    timeRefence = Math.round(timeRefence/1000 + timeout);

    srcImages();

    initBuffers();
    initTextures(texture_src[0]);

    floor = new Flat (texture_src[1], 0.0);
    floor.initTexture();

    sky = new Flat (texture_src[0], 1.55);
    sky.initTexture();

    for(var i = 0; i < n; i++){
      enemy[i] = new Pyramid(texture_src[3], texture_src[2]);
      enemy[i].initTexture();
      enemy[i].pos();
    }

    drawMaze();
  }
}
